#include <stdio.h>
#include<stdlib.h>

int hanoi(int i)
{
    if(i>1)
    {
        i--;
        return 2*hanoi(i)+1;
    }
    else
        return 1;
}

int main()
{
    int i,j;
    scanf("%d",&i);
    j = hanoi(i);
    printf("%d\n",j);
    system("pause");
    return 0;
}