{A,ab,ca,B,C,bc}
{A,ab,ac,ad,B,C,D,bc,cd}

v1.5 实现文件读取
v1.6 文件读取并绘制
v1.61 修复变色bug
v1.70 尝试吸附未成功
v1.71 完成outline.txt的读取
v1.72 完成吸附到一条线
v1.73 完成吸附和判定（大概）